Terry Ballou-Crawford
14163546
4/6/15
Programming Assignment 3

Run using INCLUDED runtests.sh script with *.py files in the same directory as the test files.